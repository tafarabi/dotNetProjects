﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalaryCalculationUI.Model
{
    class Employee
    {
        public string name;
        public string basicAmmount;
        public string rent;
        public string medical;

        public double Salary()
        {
            double s = Convert.ToDouble(basicAmmount);
            double p = ((s * Convert.ToDouble(rent))/100) + (s * Convert.ToDouble(medical) / 100);
            return s + p;
        }


        public void ShowData()
        {
            MessageBox.Show(name + " your salary is: " + Salary());
        }
    }
}
