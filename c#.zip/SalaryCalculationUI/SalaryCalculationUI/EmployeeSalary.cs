﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SalaryCalculationUI.Model;

namespace SalaryCalculationUI
{
    public partial class EmployeeSalary : Form
    {
        public EmployeeSalary()
        {
            InitializeComponent();
        }

        Employee employee = new Employee();

        private void ShowButton_Click(object sender, EventArgs e)
        {
            employee.name = nameTextBox.Text;
            employee.basicAmmount = basicTextBox.Text;
            employee.rent = rentTextBox.Text;
            employee.medical = medicalTextBox.Text;

            nameTextBox.Text = String.Empty;
            basicTextBox.Text = String.Empty;
            rentTextBox.Text = String.Empty;
            medicalTextBox.Text = String.Empty;

            employee.ShowData();
        }
    }
}
