﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Model
{
    class Calculation
    {
        public string firstNumber;
        public string secondNumber;

        public string Add()
        {
            return (Double.Parse(firstNumber) + Double.Parse(secondNumber)).ToString(); 
        }

        public string Sub()
        {
            return (Double.Parse(firstNumber) - Double.Parse(secondNumber)).ToString();
        }
        public string Mul()
        {
            return (Double.Parse(firstNumber) * Double.Parse(secondNumber)).ToString();
        }
        public string Div()
        {
            return (Double.Parse(firstNumber) / Double.Parse(secondNumber)).ToString();
        }
        public string Mod()
        {
            return (Double.Parse(firstNumber) % Double.Parse(secondNumber)).ToString();
        }
    }
}
