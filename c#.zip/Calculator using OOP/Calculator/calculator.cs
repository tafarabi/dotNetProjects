﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calculator.Model;

namespace Calculator
{
    public partial class calculatorForm : Form
    {
        public calculatorForm()
        {
            InitializeComponent();
        }

        Calculation aCalculation = new Calculation();

        private void AddButton_Click(object sender, EventArgs e)
        {
            aCalculation.firstNumber = firstTextBox.Text;
            aCalculation.secondNumber = secondTextBox.Text;

            label.Text = aCalculation.Add();
        }

        private void SubButton_Click(object sender, EventArgs e)
        {
            aCalculation.firstNumber = firstTextBox.Text;
            aCalculation.secondNumber = secondTextBox.Text;

            label.Text = aCalculation.Sub();
        }

        private void MulButton_Click(object sender, EventArgs e)
        {
            aCalculation.firstNumber = firstTextBox.Text;
            aCalculation.secondNumber = secondTextBox.Text;

            label.Text = aCalculation.Mul();
        }

        private void Divbutton_Click(object sender, EventArgs e)
        {
            aCalculation.firstNumber = firstTextBox.Text;
            aCalculation.secondNumber = secondTextBox.Text;

            label.Text = aCalculation.Div();
        }

        private void Modbutton_Click(object sender, EventArgs e)
        {

            aCalculation.firstNumber = firstTextBox.Text;
            aCalculation.secondNumber = secondTextBox.Text;

            label.Text = aCalculation.Mod();
        }
    }
}
