﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankApplicationUI.Model;

namespace BankApplicationUI
{
    public partial class BankApplication : Form
    {
        public BankApplication()
        {
            InitializeComponent();
        }

        Customer customer = new Customer();

        private void creatButton_Click(object sender, EventArgs e)
        {
            customer.accountNumber = acNumberTextBox.Text;
            customer.customerName = customerNameTextBox.Text;
            acNumberTextBox.Text=String.Empty;
            customerNameTextBox.Text=String.Empty;
   
        }

        private void DepositeButton_Click(object sender, EventArgs e)
        {
            customer.Deposit(ammountTextBox.Text);
            ammountTextBox.Text = String.Empty;
        }

        private void WithdraawButton_Click(object sender, EventArgs e)
        {
            customer.Withdraw(ammountTextBox.Text);
            ammountTextBox.Text = String.Empty;
        }

        private void ReportButton_Click(object sender, EventArgs e)
        {
            customer.ShowData();
        }
    }
}
