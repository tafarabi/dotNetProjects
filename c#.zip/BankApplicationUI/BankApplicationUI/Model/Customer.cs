﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankApplicationUI.Model
{
    class Customer
    {
        public string accountNumber;
        public string customerName;
        public string ammount;

        public void Deposit(string n)
        {
            ammount = (Convert.ToInt32(ammount) + Convert.ToInt32(n)).ToString();
        }
        public void Withdraw(string n)
        {
            ammount = (Convert.ToInt32(ammount) - Convert.ToInt32(n)).ToString();
        }

        public void ShowData()
        {
            MessageBox.Show(customerName + ", your account number is: " + accountNumber + " and balance is: " + ammount);
        }
    }
}
